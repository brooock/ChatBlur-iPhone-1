import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var processor = VideoProcessor()
    @State private var photoSelection: PhotosPickerItem?
    @State private var selectedVideoURL: URL?
    @State private var keywordText = ""
    @State private var sampleInterval = 0.12
    @State private var blurRadius = 18.0
    @State private var isFileImporterPresented = false
    @State private var isImporting = false
    @State private var importError: String?

    private struct ScanOption: Identifiable {
        let title: String
        let seconds: Double
        var id: Double { seconds }
    }

    private let scanOptions: [ScanOption] = [
        ScanOption(title: "Genau · langsamer", seconds: 0.08),
        ScanOption(title: "Ausgewogen", seconds: 0.12),
        ScanOption(title: "Schneller", seconds: 0.20)
    ]

    private var keywords: [String] {
        keywordText
            .components(separatedBy: CharacterSet(charactersIn: ",;\n"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    videoPickerSection
                    keywordSection
                    settingsSection
                    processSection
                    privacyNote
                }
                .padding(20)
                .frame(maxWidth: 620)
                .frame(maxWidth: .infinity)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("ChatBlur")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(
                isPresented: $isFileImporterPresented,
                allowedContentTypes: [.movie, .mpeg4Movie, .quickTimeMovie],
                allowsMultipleSelection: false,
                onCompletion: handleFileImport
            )
            .onChange(of: photoSelection) { newItem in
                guard let newItem else { return }
                Task { await importPhotoPickerItem(newItem) }
            }
            .alert("Import fehlgeschlagen", isPresented: Binding(
                get: { importError != nil },
                set: { if !$0 { importError = nil } }
            )) {
                Button("OK", role: .cancel) { importError = nil }
            } message: {
                Text(importError ?? "Unbekannter Fehler.")
            }
        }
        .tint(.teal)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: "eye.slash.circle.fill")
                    .font(.system(size: 34))
                    .foregroundStyle(.teal)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Bildschirmaufnahmen anonymisieren")
                        .font(.title3.bold())
                    Text("Schlagwörter automatisch erkennen und verwischen")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            Text("Für WhatsApp-Chats und andere Bildschirmvideos – auch wenn der Inhalt scrollt.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .padding(.top, 2)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.background, in: RoundedRectangle(cornerRadius: 18))
    }

    private var videoPickerSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("1", "Video auswählen")

            if let selectedVideoURL {
                HStack(spacing: 12) {
                    Image(systemName: "film.fill")
                        .font(.title2)
                        .foregroundStyle(.teal)
                        .frame(width: 42, height: 42)
                        .background(.teal.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                    VStack(alignment: .leading, spacing: 3) {
                        Text(selectedVideoURL.lastPathComponent)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(2)
                        Text("Video bereit zur Analyse")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    Button {
                        self.selectedVideoURL = nil
                        processor.reset()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                            .font(.title3)
                    }
                    .accessibilityLabel("Video entfernen")
                }
                .padding(12)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
            }

            PhotosPicker(selection: $photoSelection, matching: .videos, photoLibrary: .shared()) {
                Label("Video aus Fotos wählen", systemImage: "photo.on.rectangle.angled")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(isImporting || processor.isProcessing)

            Button {
                isFileImporterPresented = true
            } label: {
                Label("Video aus Dateien wählen", systemImage: "folder")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(isImporting || processor.isProcessing)

            if isImporting {
                ProgressView("Video wird vorbereitet …")
                    .font(.caption)
            }
        }
    }

    private var keywordSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("2", "Schlagwörter festlegen")
            Text("Ein Begriff pro Zeile oder mehrere durch Kommas trennen.")
                .font(.footnote)
                .foregroundStyle(.secondary)
            TextEditor(text: $keywordText)
                .frame(minHeight: 94)
                .padding(8)
                .scrollContentBackground(.hidden)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
                .overlay {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color(uiColor: .separator).opacity(0.45), lineWidth: 1)
                }
                .accessibilityLabel("Schlagwortliste")
            if !keywords.isEmpty {
                Text("\(keywords.count) Suchbegriff(e): \(keywords.joined(separator: " · "))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(3)
            }
        }
    }

    private var settingsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("3", "Verarbeitung einstellen")

            VStack(alignment: .leading, spacing: 7) {
                Text("Erkennungsgenauigkeit")
                    .font(.subheadline.weight(.semibold))
                Picker("Erkennungsgenauigkeit", selection: $sampleInterval) {
                    ForEach(scanOptions) { option in
                        Text(option.title).tag(option.seconds)
                    }
                }
                .pickerStyle(.menu)
                Text("Genau prüft häufiger einzelne Videobilder und kann länger dauern.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            VStack(alignment: .leading, spacing: 7) {
                HStack {
                    Text("Unschärfe")
                        .font(.subheadline.weight(.semibold))
                    Spacer()
                    Text("\(Int(blurRadius))")
                        .font(.subheadline.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
                Slider(value: $blurRadius, in: 8...30, step: 2)
                    .disabled(processor.isProcessing)
            }
        }
    }

    private var processSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("4", "Anonymisieren & exportieren")

            Button {
                guard let selectedVideoURL else { return }
                processor.start(
                    inputURL: selectedVideoURL,
                    keywords: keywords,
                    sampleInterval: sampleInterval,
                    blurRadius: blurRadius
                )
            } label: {
                HStack {
                    if processor.isProcessing {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "wand.and.stars")
                    }
                    Text(processor.isProcessing ? "Video wird verarbeitet …" : "Blur anwenden und Video erstellen")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 4)
            }
            .buttonStyle(.borderedProminent)
            .disabled(selectedVideoURL == nil || keywords.isEmpty || processor.isProcessing || isImporting)

            if processor.isProcessing || processor.outputURL != nil {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: processor.progress)
                    Text(processor.status)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(12)
                .background(.background, in: RoundedRectangle(cornerRadius: 12))
            }

            if let outputURL = processor.outputURL {
                ShareLink(item: MovieTransferable(url: outputURL)) {
                    Label("Bearbeitetes Video teilen / sichern", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }

            if let error = processor.errorMessage {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var privacyNote: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "iphone.and.arrow.forward")
                .foregroundStyle(.teal)
            VStack(alignment: .leading, spacing: 4) {
                Text("Lokal auf dem iPhone")
                    .font(.subheadline.weight(.semibold))
                Text("Die Analyse findet auf dem Gerät statt. Diese erste Version verwischt die erkannte Textzeile, in der ein Schlagwort vorkommt. Bitte das exportierte Video prüfen: OCR kann Text übersehen, besonders bei sehr schnellem Scrollen.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.teal.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
    }

    private func sectionTitle(_ number: String, _ title: String) -> some View {
        HStack(spacing: 10) {
            Text(number)
                .font(.caption.bold())
                .foregroundStyle(.white)
                .frame(width: 25, height: 25)
                .background(Color.teal, in: Circle())
            Text(title).font(.headline)
        }
    }

    @MainActor
    private func importPhotoPickerItem(_ item: PhotosPickerItem) async {
        isImporting = true
        defer { isImporting = false }
        do {
            guard let movie = try await item.loadTransferable(type: MovieTransferable.self) else {
                throw ImportProblem.couldNotReadVideo
            }
            selectedVideoURL = movie.url
            processor.reset()
        } catch {
            importError = "Das Video konnte nicht aus Fotos geladen werden. Bitte versuche es über „Dateien wählen“. Details: \(error.localizedDescription)"
        }
    }

    private func handleFileImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let pickedURL = urls.first else { return }
            do {
                let hasAccess = pickedURL.startAccessingSecurityScopedResource()
                defer { if hasAccess { pickedURL.stopAccessingSecurityScopedResource() } }
                let destination = FileManager.default.temporaryDirectory
                    .appendingPathComponent("ChatBlur-import-\(UUID().uuidString)-\(pickedURL.lastPathComponent)")
                try FileManager.default.copyItem(at: pickedURL, to: destination)
                selectedVideoURL = destination
                processor.reset()
            } catch {
                importError = "Die Datei konnte nicht kopiert werden: \(error.localizedDescription)"
            }
        case .failure(let error):
            importError = error.localizedDescription
        }
    }

    private enum ImportProblem: LocalizedError {
        case couldNotReadVideo
        var errorDescription: String? { "Es wurde keine Videodatei geliefert." }
    }
}
