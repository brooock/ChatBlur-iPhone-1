import SwiftUI

@main
struct ChatBlurApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
