import Foundation
import Combine
import AVFoundation
import CoreImage
import Vision
import ImageIO

private struct DetectionSample {
    let time: Double
    let boxes: [CGRect]
}

private struct BoxObservation {
    let time: Double
    let rect: CGRect
}

private struct BoxTrack {
    var observations: [BoxObservation]
}

private enum ProcessingError: LocalizedError {
    case invalidVideo
    case noVideoTrack
    case cannotCreateExporter
    case exportFailed

    var errorDescription: String? {
        switch self {
        case .invalidVideo: return "Die Videodatei hat keine gültige Länge oder konnte nicht gelesen werden."
        case .noVideoTrack: return "In der Datei wurde keine Videospur gefunden."
        case .cannotCreateExporter: return "Der Videoexport konnte nicht gestartet werden."
        case .exportFailed: return "Der Videoexport ist fehlgeschlagen. Bitte ein anderes Video ausprobieren."
        }
    }
}

@MainActor
final class VideoProcessor: ObservableObject {
    @Published private(set) var isProcessing = false
    @Published private(set) var progress = 0.0
    @Published private(set) var status = "Bereit"
    @Published private(set) var outputURL: URL?
    @Published private(set) var errorMessage: String?

    func reset() {
        guard !isProcessing else { return }
        progress = 0
        status = "Bereit"
        outputURL = nil
        errorMessage = nil
    }

    func start(inputURL: URL, keywords: [String], sampleInterval: Double, blurRadius: Double) {
        guard !isProcessing else { return }
        let cleanKeywords = keywords.map(Self.normalize).filter { !$0.isEmpty }
        guard !cleanKeywords.isEmpty else {
            errorMessage = "Bitte mindestens ein Schlagwort eingeben."
            return
        }

        isProcessing = true
        progress = 0
        status = "Video wird vorbereitet …"
        outputURL = nil
        errorMessage = nil

        Task.detached(priority: .userInitiated) { [weak self] in
            do {
                let result = try await Self.processVideo(
                    inputURL: inputURL,
                    keywords: cleanKeywords,
                    sampleInterval: sampleInterval,
                    blurRadius: blurRadius,
                    update: { newProgress, newStatus in
                        Task { @MainActor [weak self] in
                            self?.progress = newProgress
                            self?.status = newStatus
                        }
                    }
                )
                await MainActor.run {
                    self?.outputURL = result
                    self?.progress = 1
                    self?.status = "Fertig. Bitte das Ergebnis kontrollieren."
                    self?.isProcessing = false
                }
            } catch {
                await MainActor.run {
                    self?.errorMessage = error.localizedDescription
                    self?.status = "Verarbeitung fehlgeschlagen"
                    self?.isProcessing = false
                }
            }
        }
    }

    nonisolated private static func processVideo(
        inputURL: URL,
        keywords: [String],
        sampleInterval: Double,
        blurRadius: Double,
        update: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        let asset = AVURLAsset(url: inputURL)
        let duration = asset.duration.seconds
        guard duration.isFinite, duration > 0 else {
            throw ProcessingError.invalidVideo
        }
        guard asset.tracks(withMediaType: .video).first != nil else {
            throw ProcessingError.noVideoTrack
        }

        update(0.02, "Videolänge wird geprüft …")
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 1280, height: 1280)
        generator.requestedTimeToleranceBefore = CMTime(seconds: 0.04, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.04, preferredTimescale: 600)

        let step = max(0.06, sampleInterval)
        let sampleCount = max(1, Int(ceil(duration / step)))
        var samples: [DetectionSample] = []
        samples.reserveCapacity(min(sampleCount, 100_000))

        for index in 0..<sampleCount {
            try Task.checkCancellation()
            let seconds = min(Double(index) * step, max(0, duration - 0.01))
            let time = CMTime(seconds: seconds, preferredTimescale: 600)
            var detectedBoxes: [CGRect] = []

            do {
                let cgImage = try generator.copyCGImage(at: time, actualTime: nil)
                detectedBoxes = try detectKeywordBoxes(in: cgImage, keywords: keywords)
            } catch {
                // A single undecodable frame should not prevent the remainder of the video from processing.
            }
            samples.append(DetectionSample(time: seconds, boxes: detectedBoxes))

            if index % 3 == 0 || index == sampleCount - 1 {
                let fraction = Double(index + 1) / Double(sampleCount)
                update(0.05 + 0.57 * fraction, "Text wird analysiert: \(index + 1) / \(sampleCount) Bild(er)")
            }
        }

        let tracks = buildTracks(from: samples, maxGap: max(0.32, step * 2.5))
        let hitCount = samples.reduce(0) { $0 + $1.boxes.count }
        update(0.64, "\(hitCount) Treffer in Analysebildern · Blur wird vorbereitet …")

        let outputURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("ChatBlur-\(Int(Date().timeIntervalSince1970))-\(UUID().uuidString.prefix(6)).mp4")
        try? FileManager.default.removeItem(at: outputURL)

        let intervalForMasks = step
        let renderRadius = max(2.0, blurRadius)
        let composition = AVVideoComposition(asset: asset, applyingCIFiltersWithHandler: { request in
            let source = request.sourceImage.clampedToExtent()
            let extent = request.sourceImage.extent
            let currentTime = request.compositionTime.seconds
            let rectangles = Self.activeRectangles(in: tracks, at: currentTime, halfInterval: intervalForMasks / 2 + 0.015)

            if rectangles.isEmpty {
                request.finish(with: request.sourceImage, context: nil)
                return
            }

            let blurred = source
                .applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: renderRadius])
                .cropped(to: extent)
            var output = request.sourceImage

            for normalizedRect in rectangles {
                let pixelRect = CGRect(
                    x: extent.minX + normalizedRect.minX * extent.width,
                    y: extent.minY + normalizedRect.minY * extent.height,
                    width: normalizedRect.width * extent.width,
                    height: normalizedRect.height * extent.height
                )
                let padded = pixelRect.insetBy(
                    dx: -max(5, pixelRect.width * 0.04),
                    dy: -max(3, pixelRect.height * 0.18)
                ).intersection(extent)
                guard !padded.isNull, !padded.isEmpty else { continue }
                let blurredRegion = blurred.cropped(to: padded)
                output = blurredRegion.composited(over: output)
            }
            request.finish(with: output.cropped(to: extent), context: nil)
        })

        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            throw ProcessingError.cannotCreateExporter
        }
        exporter.videoComposition = composition
        exporter.outputURL = outputURL
        exporter.outputFileType = .mp4
        exporter.shouldOptimizeForNetworkUse = true

        update(0.68, "Video wird gerendert und Ton wird übernommen …")
        let exportTask = Task.detached {
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                exporter.exportAsynchronously {
                    continuation.resume()
                }
            }
        }
        let progressTask = Task.detached {
            while !Task.isCancelled {
                let value = Double(exporter.progress)
                update(0.68 + value * 0.30, "Video wird exportiert … \(Int(value * 100)) %")
                switch exporter.status {
                case .completed, .failed, .cancelled:
                    return
                default:
                    try? await Task.sleep(nanoseconds: 350_000_000)
                }
            }
        }

        await exportTask.value
        progressTask.cancel()

        guard exporter.status == .completed else {
            try? FileManager.default.removeItem(at: outputURL)
            throw exporter.error ?? ProcessingError.exportFailed
        }
        update(0.99, "Export abgeschlossen …")
        return outputURL
    }

    nonisolated private static func detectKeywordBoxes(in image: CGImage, keywords: [String]) throws -> [CGRect] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        request.minimumTextHeight = 0.004
        let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
        try handler.perform([request])

        let observations = request.results ?? []
        var boxes: [CGRect] = []
        for observation in observations {
            guard let candidate = observation.topCandidates(1).first else { continue }
            let line = normalize(candidate.string)
            guard !line.isEmpty else { continue }

            let containsKeyword = keywords.contains { keyword in
                line == keyword || line.contains(" \(keyword) ") || line.hasPrefix("\(keyword) ") || line.hasSuffix(" \(keyword)")
            }
            if containsKeyword {
                boxes.append(observation.boundingBox.integralNormalized())
            }
        }
        return boxes
    }

    nonisolated private static func buildTracks(from samples: [DetectionSample], maxGap: Double) -> [BoxTrack] {
        var tracks: [BoxTrack] = []

        for sample in samples {
            var usedTrackIndices = Set<Int>()
            let orderedBoxes = sample.boxes.sorted {
                if abs($0.midY - $1.midY) > 0.02 { return $0.midY > $1.midY }
                return $0.midX < $1.midX
            }

            for box in orderedBoxes {
                var bestIndex: Int?
                var bestDistance = CGFloat.greatestFiniteMagnitude

                for trackIndex in tracks.indices where !usedTrackIndices.contains(trackIndex) {
                    guard let last = tracks[trackIndex].observations.last,
                          sample.time - last.time <= maxGap else { continue }
                    let distance = centerDistance(last.rect, box)
                    if distance < bestDistance && distance < 0.24 {
                        bestDistance = distance
                        bestIndex = trackIndex
                    }
                }

                let observation = BoxObservation(time: sample.time, rect: box)
                if let bestIndex {
                    tracks[bestIndex].observations.append(observation)
                    usedTrackIndices.insert(bestIndex)
                } else {
                    tracks.append(BoxTrack(observations: [observation]))
                    usedTrackIndices.insert(tracks.count - 1)
                }
            }
        }
        return tracks
    }

    nonisolated private static func activeRectangles(in tracks: [BoxTrack], at time: Double, halfInterval: Double) -> [CGRect] {
        var results: [CGRect] = []
        for track in tracks {
            let observations = track.observations
            guard let first = observations.first, let last = observations.last else { continue }
            guard time >= first.time - halfInterval, time <= last.time + halfInterval else { continue }

            if observations.count == 1 {
                results.append(first.rect)
                continue
            }

            if time <= first.time {
                results.append(first.rect)
                continue
            }
            if time >= last.time {
                results.append(last.rect)
                continue
            }

            var interpolated: CGRect?
            for index in 0..<(observations.count - 1) {
                let a = observations[index]
                let b = observations[index + 1]
                if time >= a.time && time <= b.time {
                    let span = max(0.0001, b.time - a.time)
                    let fraction = min(1, max(0, (time - a.time) / span))
                    interpolated = interpolate(a.rect, b.rect, fraction: fraction)
                    break
                }
            }
            results.append(interpolated ?? last.rect)
        }
        return results
    }

    nonisolated private static func interpolate(_ a: CGRect, _ b: CGRect, fraction: Double) -> CGRect {
        let f = CGFloat(fraction)
        return CGRect(
            x: a.origin.x + (b.origin.x - a.origin.x) * f,
            y: a.origin.y + (b.origin.y - a.origin.y) * f,
            width: a.width + (b.width - a.width) * f,
            height: a.height + (b.height - a.height) * f
        )
    }

    nonisolated private static func centerDistance(_ a: CGRect, _ b: CGRect) -> CGFloat {
        let dx = a.midX - b.midX
        let dy = a.midY - b.midY
        return sqrt(dx * dx + dy * dy)
    }

    nonisolated fileprivate static func normalize(_ input: String) -> String {
        let folded = input.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "de_DE"))
        let scalars = folded.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? String($0) : " " }.joined()
        return scalars.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }

}

private extension CGRect {
    /// Keeps Vision's normalized bounding box within the expected unit square.
    func integralNormalized() -> CGRect {
        let minX = max(0, min(1, origin.x))
        let minY = max(0, min(1, origin.y))
        let maxX = max(minX, min(1, origin.x + size.width))
        let maxY = max(minY, min(1, origin.y + size.height))
        return CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
    }
}
