# ChatBlur für iPhone XR – iOS-Prototyp

ChatBlur ist ein nativer SwiftUI-Prototyp für iPhone, der Bildschirmaufnahmen lokal analysiert und Textzeilen mit frei eingegebenen Schlagwörtern automatisch verwischt. Er ist speziell als Startpunkt für scrollende WhatsApp-Chats gedacht, kann aber auch andere Bildschirmaufnahmen verarbeiten.

## Funktionen in dieser ersten Version

- Videos aus „Fotos“ oder der Dateien-App auswählen.
- Eigene Schlagwörter eingeben; Groß-/Kleinschreibung und Akzente werden bei der Suche ignoriert.
- OCR mit Apples Vision-Framework direkt auf dem Gerät.
- Mehrere Analysefrequenzen auswählen.
- Positionen erkannter Treffer über die Zeit zuordnen und zwischen Erkennungen interpolieren, damit Blur-Felder beim Scrollen mitwandern.
- Unschärfe einstellen, Video als MP4 exportieren und über das iOS-Teilen-Menü sichern.
- Es gibt keinen Cloud-Upload und keinen externen API-Schlüssel.

## Bekannte Grenzen

Dies ist ein MVP, keine produktionsreife Datenschutzgarantie. Die aktuelle Fassung verwischt **die erkannte Textzeile**, in der ein Schlagwort vorkommt, nicht nur die einzelnen Buchstaben und auch nicht automatisch die ganze Nachrichtenblase. OCR kann Text übersehen, besonders bei sehr schnellem Scrollen, kleinen Schriften, Kompression, Animationen oder Übergängen. Ein Begriff, der nur kürzer als das gewählte Scanintervall sichtbar ist, kann übersehen werden. Vor dem Teilen muss das exportierte Video vollständig geprüft werden.

Die erste Version hat noch keine interaktive Frame-für-Frame-Vorschau, keine manuelle Korrekturmaske und keine Erkennung gesprochener Wörter. Der Export läuft lokal auf dem iPhone; lange oder hochauflösende Videos können auf älteren Geräten langsam sein oder viel Speicher benötigen.

## Auf dem Mac öffnen und auf dem iPhone XR ausführen

1. ZIP-Datei entpacken.
2. `ChatBlur.xcodeproj` mit Xcode öffnen.
3. Im Projekt-Target **ChatBlur** den Bereich **Signing & Capabilities** öffnen und ein eigenes Team auswählen. Falls nötig, den Bundle Identifier `de.local.chatblur` auf einen eindeutigen Wert ändern.
4. iPhone XR per Kabel oder drahtlos verbinden und als Run Destination wählen.
5. In Xcode auf **Run** drücken. Wenn das iPhone den Entwickler noch nicht vertraut, die entsprechende Geräte-/Entwicklereinstellung bestätigen.

Das Projekt ist für iOS 16.0 und neuer eingestellt und verwendet Standard-Frameworks von Apple (SwiftUI, PhotosUI, AVFoundation, Core Image und Vision). Das iPhone XR ist laut Apples Sicherheitsübersicht weiterhin in der iOS-18-Gerätegruppe; iOS 26 setzt ein iPhone 11 oder neuer voraus. Daher ist die iOS-16-Mindestversion für das XR passend.

## Technischer Ablauf

1. `AVAssetImageGenerator` erzeugt Analysebilder in einem einstellbaren Zeitabstand.
2. `VNRecognizeTextRequest` erkennt Text und dessen normalisierte Position.
3. Treffer werden anhand ihrer räumlichen Nähe über aufeinanderfolgende Analysebilder zu Tracks zusammengeführt.
4. Während des Exports ermittelt eine `AVVideoComposition` zu jedem Zeitpunkt die passenden Positionen und legt dort einen Core-Image-Gaußschen Blur über das Video. Der Export erfolgt mit `AVAssetExportSession`, damit die vorhandene Tonspur erhalten bleibt.

## Wichtiger Hinweis zum Build

Die Projektdateien und der Swift-Code wurden hier als Xcode-Projekt vorbereitet. Die aktuelle Ausführungsumgebung stellt jedoch kein macOS und kein `xcodebuild` bereit. Daher konnte ich das Projekt hier nicht mit Apples Compiler bauen oder auf einem echten iPhone XR testen. Vor dem praktischen Einsatz bitte in Xcode kompilieren und mit Testmaterial prüfen.

## Wenn du Windows verwendest

Du musst keinen Mac kaufen, um den Quellcode zu bearbeiten. Ein natives SwiftUI-Projekt kann aber nicht direkt mit Windows kompiliert werden, weil dafür Apples Xcode auf macOS benötigt wird. Im Projekt liegt deshalb eine `codemagic.yaml` für einen Cloud-Build auf einem macOS-Build-Rechner.

### Cloud-Build auf Codemagic

1. Entpacke die ZIP-Datei auf Windows.
2. Erstelle auf GitHub ein **privates** Repository.
3. Lade den **Inhalt des Ordners `ChatBlur-iPhone`** in die oberste Ebene des Repositorys hoch. Dort müssen `ChatBlur.xcodeproj`, der Ordner `ChatBlur` und `codemagic.yaml` direkt zu sehen sein.
4. Melde dich bei Codemagic an und verbinde dein GitHub-Konto.
5. Füge das Repository als iOS-App hinzu. Lass Codemagic die `codemagic.yaml` auf dem Branch `main` erkennen und starte den Workflow **ChatBlur – iOS compile check (Windows-friendly cloud build)**.
6. Nach erfolgreichem Lauf findest du das Simulator-Build und das Build-Log unter den Artefakten.

**Wichtig:** Dieser erste Workflow prüft die Kompilierung für den iOS-Simulator. Die erzeugte Simulator-App lässt sich nicht auf dem echten iPhone XR installieren. Dafür ist zusätzlich ein korrekt signierter iOS-Build notwendig. Für eine bequeme Installation über TestFlight brauchst du eine Apple-Developer-Program-Mitgliedschaft und musst die Signierung in Codemagic konfigurieren. Siehe die aktuelle Codemagic-Anleitung: https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/

Das hier bereitgestellte ZIP enthält Quellcode und Build-Konfiguration, **keine installierbare IPA-Datei**. Ein erfolgreicher Cloud-Build und ein Gerätetest wurden noch nicht ausgeführt.
